public class TesteFuncionarios {
    public static void main(String[] args) {
   
        Gerente gerente = new Gerente("Carlos", 5000.00, 1500.00);
        System.out.println("Salário do Gerente " + gerente.getNome() + ": " + gerente.calcularSalario());

        Assistente assistente = new Assistente("Ana", 3000.00);
        System.out.println("Salário do Assistente " + assistente.getNome() + ": " + assistente.calcularSalario());
    }
}
