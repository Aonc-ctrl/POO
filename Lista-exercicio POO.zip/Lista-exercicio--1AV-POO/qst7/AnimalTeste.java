package qst7;

public class AnimalTeste {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro("Akira", 3);
        Gato g1 = new Gato("Mingaul", 9);

        c1.emitirSom();
        g1.emitirSom();
    }
}
