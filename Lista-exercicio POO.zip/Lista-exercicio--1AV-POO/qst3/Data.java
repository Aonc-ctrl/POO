package qst3;

public class Data {
    private int dia, mes, ano;

    public void displayData() {
        System.out.println(dia + "/" + mes + "/" + ano);
    }

    public Data(int dia, int mes, int ano) {
        setDia(dia);
        setMes(mes);
        this.ano = ano; 
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        if (mes > 0 && mes <= 12) {
            this.mes = mes;
        } else {
            this.mes = 1;
        }
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        if (dia > 0 && dia <= 31) {
            this.dia = dia;
        } else {
            this.dia = 1; 
        }
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }


}
