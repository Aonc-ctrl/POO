package qst3;

public class DataTeste {
    public static void main(String[] args) {
        Data d1 = new Data(21, 12, 2321);

        d1.displayData();
    }
}
