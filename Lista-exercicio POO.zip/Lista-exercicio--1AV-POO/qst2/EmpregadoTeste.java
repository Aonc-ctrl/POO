package qst2;
public class EmpregadoTeste {
    public static void main(String[] args) {
        Emprego p1 = new Emprego("arthur ", "Araujo", 3000);
        Emprego p2 = new Emprego("João", "Oliveira", 4000.00);
        System.out.println("o Salario de " + p1.getNome() + p1.getSobreNome() +"e de R$: "+ p1.getsalarioAnual());
        System.out.println("o Salario de " + p2.getNome() + p2.getSobreNome() +"e de R$: "+ p2.getsalarioAnual());

        p1.aumetoPercentual(10);
        p2.aumetoPercentual(10);

        System.out.println("Novo salario anual de " + p1.getNome() +  p1.getSobreNome() + " apos 10% de aumento R$: " + p1.getsalarioAnual());
        System.out.println("Novo salario anual de " + p2.getNome() +  p2.getSobreNome() + " apos 10% de aumento R$: " + p2.getsalarioAnual());
    }
}
