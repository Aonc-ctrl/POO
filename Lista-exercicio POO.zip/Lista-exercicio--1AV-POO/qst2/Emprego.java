package qst2;

public class Emprego {
    private String nome, sobreNome;
    private double salarioMensal;
    
    public Emprego(String nome, String sobreNome, double salarioMensal) {
        this.nome = nome;
        this.sobreNome = sobreNome;
        this.salarioMensal = salarioMensal;
    }


    public double getsalarioAnual(){
        double salarioTotal = salarioMensal * 12;
        return salarioTotal;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getSobreNome() {
        return sobreNome;
    }
    public void setSobreNome(String sobreNome) {
        this.sobreNome = sobreNome;
    }
    public double getSalarioMensal() {
        return salarioMensal;
    }
    public void setSalarioMensal(double salarioMensal) {
        if (salarioMensal > 0) {
            this.salarioMensal = salarioMensal;
        } else {
            this.salarioMensal = 0.0;
        }
    }
    
    public void aumetoPercentual(double percentual) {
        salarioMensal += salarioMensal * (percentual / 100);
    }
}
