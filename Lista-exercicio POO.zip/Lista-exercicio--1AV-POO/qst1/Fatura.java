
public class Fatura {
    private String codigoProduto, descricaoProduto;
    private int quantidadeComprada;
    private double precoPorItem;

    public Fatura(String codigoProduto, String descricaoProduto, int quantidadeComprada, double precoPorItem) {
        this.codigoProduto = codigoProduto;
        this.descricaoProduto = descricaoProduto;
        setQuantidadeComprada(quantidadeComprada); 
        setPrecoPorItem(precoPorItem);             
    }

    public String getTotalFatura() {
        double totalFatura = quantidadeComprada * precoPorItem;
        return String.format("%.2f", totalFatura);
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDescricaoProduto() {
        return descricaoProduto;
    }

    public void setDescricaoProduto(String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }

    public int getQuantidadeComprada() {
        return quantidadeComprada;
    }

    public void setQuantidadeComprada(int quantidadeComprada) {
        this.quantidadeComprada = (quantidadeComprada > 0) ? quantidadeComprada : 0;
    }

    public double getPrecoPorItem() {
        return precoPorItem;
    }

    public void setPrecoPorItem(double precoPorItem) {
        this.precoPorItem = (precoPorItem > 0) ? precoPorItem : 0.0;
    }
}
