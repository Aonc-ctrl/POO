public class FaturaTeste {
    public static void main(String[] args) {
        Fatura p1 = new Fatura("1231231","mause gamer",39,128.32);

        System.out.println("total da fatura: "+p1.getTotalFatura());
    }  
}
