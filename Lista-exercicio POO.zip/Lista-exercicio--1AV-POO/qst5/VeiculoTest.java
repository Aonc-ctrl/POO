package qst5;

public class VeiculoTest {
    public static void main(String[] args) {
        Carro c1 = new Carro("Mercedes", "ck4", 2019, 4);
        Moto m1 = new Moto("Kauzaki", "9800xs", 2010, "Antenaddo");
        c1.exibirDetalhes();
        m1.exibirDetalhes();
    }
}
