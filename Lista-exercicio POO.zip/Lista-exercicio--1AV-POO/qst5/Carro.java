package qst5;

public class Carro extends Veiculo{
    private int numeroDePortas;

    @Override
    public void exibirDetalhes(){ 
        super.exibirDetalhes();
        System.out.println("Numero de Portas: "+getNumeroDePortas());
    }
    

    public Carro(String marca, String modelo, int ano, int numeroDePortas) {
        super(marca, modelo, ano);
        this.numeroDePortas = numeroDePortas;
    }


    public int getNumeroDePortas() {
        return numeroDePortas;
    }

    public void setNumeroDePortas(int numeroDePortas) {
        this.numeroDePortas = numeroDePortas;
    }
    
}
