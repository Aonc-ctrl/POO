
public class Main {
    public static void main(String[] args) {
      
        Eletronico eletronico = new Eletronico("Smartphone", 1000.00, 12);
        System.out.println("Produto: " + eletronico.getNome());
        System.out.println("Preço original: R$ " + eletronico.getPreco());
        System.out.println("Preço com desconto: R$ " + eletronico.calcularPrecoComDesconto());

        
        Alimento alimento = new Alimento("Arroz", 20.00, "2025-12-31");
        System.out.println("\nProduto: " + alimento.getNome());
        System.out.println("Preço original: R$ " + alimento.getPreco());
        System.out.println("Preço com desconto: R$ " + alimento.calcularPrecoComDesconto());
    }
}

